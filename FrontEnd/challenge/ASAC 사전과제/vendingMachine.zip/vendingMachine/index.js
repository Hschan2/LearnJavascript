let totalAmount = 0;
let selectedMoneyValue = 0;
let selectedDrinks = [];
const selectedMoney = document.getElementById("selectedMoney");
const money = document.getElementById("money");

function increaseAmount(amount) {
    selectedDrink(amount)
    selectedMoney.innerText = `선택한 음료 총 금액: ${selectedMoneyValue}`;
}

function selectedDrink(amount) {
    if (amount === 300) {
        selectedDrinks.push("비타민 음료");
        totalAmount -= 300;
        selectedMoneyValue += amount;
        if (totalAmount < 0) {
            selectedDrinks.pop();
            totalAmount += 300;
            selectedMoneyValue -= amount;
            window.alert("잔액이 부족합니다.");
        }
    }
    if (amount === 500) {
        selectedDrinks.push("사이다");
        totalAmount -= 500;
        selectedMoneyValue += amount;
        if (totalAmount < 0) {
            selectedDrinks.pop();
            totalAmount += 500;
            selectedMoneyValue -= amount;
            window.alert("잔액이 부족합니다.");
        }
    }
    if (amount === 1000) {
        selectedDrinks.push("콜라");
        totalAmount -= 1000;
        selectedMoneyValue += amount;
        if (totalAmount < 0) {
            selectedDrinks.pop();
            totalAmount += 1000;
            selectedMoneyValue -= amount;
            window.alert("잔액이 부족합니다.");
        }
    }
}

function insertAmount(amount) {
    totalAmount += amount;
    money.innerText = `잔액 총 금액: ${totalAmount}`;
}

function showResult() {
    const output = document.getElementById("output");
    output.innerText = `남은 총 금액: ${totalAmount}원\n선택된 음료: ${selectedDrinks.join(", ")}`;
}